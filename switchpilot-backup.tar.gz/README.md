# SwitchPilot — Your AI Job Search Copilot

SwitchPilot is an intelligent job search assistant powered by Google Agent Development Kit (ADK), Gemini, and Agent Engine. It discovers relevant job opportunities, evaluates truthful skill fit against candidate backgrounds without inflating qualifications, and tracks active application pipelines.

![SwitchPilot Demo](demo.gif)

---

## Implemented Capabilities

- **Live & Saved Job Discovery**:
  - Remotive Remote Developer API (`search_remote_jobs_api`) for live engineering listings.
  - Greenhouse Job Board integration (`fetch_live_greenhouse_jobs`).
  - Google Cloud Firestore (`jobpilot_jobs`) curated role repository (`list_saved_jobs`, `add_job_listing`).
- **Truthful Fit Evaluation & Skill Matching**:
  - Compares verified candidate skills with specific job requirements.
  - Explains evidence-backed matches and explicitly highlights missing skills or learning opportunities.
  - Generates zero-hallucination evaluations without exaggerating candidate experience.
- **Application Pipeline Tracking**:
  - Tracks candidate job statuses in Google Cloud Firestore (`jobpilot_applications`) across stages: *Saved*, *Preparing*, *Ready*, *Applied*, *Interview*, *Offer*, *Rejected*.
  - Opening job links never marks jobs as applied prematurely; statuses update explicitly via `update_application`.
- **A2UI Rich Card Rendering**:
  - Natively renders A2UI v0.8 Basic Catalog UI cards (`Card`, `Column`, `Row`, `Text`, `Divider`, `Image`, `Icon`).
- **Isolated Multi-Session Architecture**:
  - Dynamic client session generation avoids hardcoded identity sharing across distinct visitors.
  - Context retention across multi-turn queries via A2A protocol.

---

## Planned / Unimplemented Capabilities

- **Resume Studio Diffing**: Direct side-by-side resume editing and automated file rewriting is not yet implemented as an autonomous agent tool; it is clearly marked as **Planned** in the UI.
- **One-Click Auto-Apply**: The agent does not automate submissions on third-party employer portals; candidates are provided direct, official posting URLs.

---

## Architecture Overview

```
Browser Client (SwitchPilot UI)
    │
    │  HTTP POST /chat (session-isolated)
    ▼
FastAPI Proxy (Cloud Run / Local)
    │
    │  A2A JSON-RPC / HTTP Streaming (IAM Token Auth)
    ▼
Vertex AI Reasoning Engine (ADK Agent Platform)
    │
    ├── Remotive Public Jobs API
    ├── Greenhouse Board API
    └── Google Cloud Firestore (jobpilot_jobs, jobpilot_applications)
```

---

## Local Setup & Run

### Prerequisites

- Python 3.10+
- Google Cloud SDK (`gcloud`) authenticated to your GCP project.
- Access to deployed ADK Agent Platform Reasoning Engine or local ADK runtime.

### Steps

1. **Clone the repository**:
   ```bash
   git clone https://github.com/<your-username>/buildwithgemini-switchpilot.git
   cd buildwithgemini-switchpilot
   ```

2. **Set up the virtual environment**:
   ```bash
   cd jobpilot-agent/frontend
   python -m venv .venv
   source .venv/bin/activate
   pip install -r requirements.txt
   ```

3. **Configure environment variables**:
   ```bash
   export AGENT_ENGINE_RESOURCE_NAME="projects/<PROJECT_ID>/locations/<REGION>/reasoningEngines/<ENGINE_ID>"
   export AGENT_DIRECTORY="app"
   ```

4. **Launch the server**:
   ```bash
   python main.py
   ```
   Open `http://localhost:8080` in your browser.
